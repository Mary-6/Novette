--
-- PostgreSQL database dump
--

\restrict UEAQAj1EyLFyHpvnTrByxUOsoLsEMdWQglUHjYhWDFgzFDXebAJLzky93gLOqG3

-- Dumped from database version 16.15 (Debian 16.15-1.pgdg13+2)
-- Dumped by pg_dump version 16.15 (Debian 16.15-1.pgdg13+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: AuthToken; Type: TABLE; Schema: public; Owner: aurelian
--

CREATE TABLE public."AuthToken" (
    id text NOT NULL,
    "userId" text NOT NULL,
    kind text NOT NULL,
    "tokenHash" text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "usedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."AuthToken" OWNER TO aurelian;

--
-- Name: CartItem; Type: TABLE; Schema: public; Owner: aurelian
--

CREATE TABLE public."CartItem" (
    "userId" text NOT NULL,
    "watchId" text NOT NULL,
    qty integer DEFAULT 1 NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."CartItem" OWNER TO aurelian;

--
-- Name: ContactMessage; Type: TABLE; Schema: public; Owner: aurelian
--

CREATE TABLE public."ContactMessage" (
    id text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    subject text,
    message text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."ContactMessage" OWNER TO aurelian;

--
-- Name: NewsletterSubscriber; Type: TABLE; Schema: public; Owner: aurelian
--

CREATE TABLE public."NewsletterSubscriber" (
    id text NOT NULL,
    email text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."NewsletterSubscriber" OWNER TO aurelian;

--
-- Name: Order; Type: TABLE; Schema: public; Owner: aurelian
--

CREATE TABLE public."Order" (
    id text NOT NULL,
    number text NOT NULL,
    "userId" text,
    email text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    "customerName" text NOT NULL,
    "shippingMethod" text NOT NULL,
    "shippingPrice" integer NOT NULL,
    subtotal integer NOT NULL,
    total integer NOT NULL,
    "paymentMethod" text NOT NULL,
    address jsonb NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Order" OWNER TO aurelian;

--
-- Name: OrderItem; Type: TABLE; Schema: public; Owner: aurelian
--

CREATE TABLE public."OrderItem" (
    id text NOT NULL,
    "orderId" text NOT NULL,
    "watchId" text NOT NULL,
    model text NOT NULL,
    reference text NOT NULL,
    brand text NOT NULL,
    qty integer NOT NULL,
    price integer NOT NULL
);


ALTER TABLE public."OrderItem" OWNER TO aurelian;

--
-- Name: Session; Type: TABLE; Schema: public; Owner: aurelian
--

CREATE TABLE public."Session" (
    id text NOT NULL,
    token text NOT NULL,
    "userId" text NOT NULL,
    remember boolean DEFAULT true NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Session" OWNER TO aurelian;

--
-- Name: User; Type: TABLE; Schema: public; Owner: aurelian
--

CREATE TABLE public."User" (
    id text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    "passwordHash" text NOT NULL,
    role text DEFAULT 'customer'::text NOT NULL,
    "emailVerifiedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."User" OWNER TO aurelian;

--
-- Name: Watch; Type: TABLE; Schema: public; Owner: aurelian
--

CREATE TABLE public."Watch" (
    id text NOT NULL,
    slug text NOT NULL,
    "brandSlug" text NOT NULL,
    model text NOT NULL,
    reference text NOT NULL,
    nickname text,
    price integer NOT NULL,
    year integer NOT NULL,
    type text NOT NULL,
    material text,
    condition text NOT NULL,
    gender text NOT NULL,
    "boxPapers" boolean NOT NULL,
    "isNew" boolean NOT NULL,
    "isFeatured" boolean NOT NULL,
    popularity integer NOT NULL,
    "addedAt" timestamp(3) without time zone NOT NULL,
    description text NOT NULL,
    specs jsonb NOT NULL,
    inventory integer DEFAULT 1 NOT NULL
);


ALTER TABLE public."Watch" OWNER TO aurelian;

--
-- Name: WishlistItem; Type: TABLE; Schema: public; Owner: aurelian
--

CREATE TABLE public."WishlistItem" (
    "userId" text NOT NULL,
    "watchId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."WishlistItem" OWNER TO aurelian;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: aurelian
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO aurelian;

--
-- Data for Name: AuthToken; Type: TABLE DATA; Schema: public; Owner: aurelian
--

COPY public."AuthToken" (id, "userId", kind, "tokenHash", "expiresAt", "usedAt", "createdAt") FROM stdin;
cmujlmlcw0002qhsgdb27ama8	cmujlmlcu0000qhsga9y93hpe	verify_email	f1f09e2920832e7fe19f4ce2eeccc1f45c39e06386e5dc6221a3b500df3a9ad0	2026-09-28 09:11:03.584	\N	2026-09-27 09:11:03.585
\.


--
-- Data for Name: CartItem; Type: TABLE DATA; Schema: public; Owner: aurelian
--

COPY public."CartItem" ("userId", "watchId", qty, "updatedAt") FROM stdin;
cmujlmlcu0000qhsga9y93hpe	rlx-01	1	2026-09-27 09:11:22.295
\.


--
-- Data for Name: ContactMessage; Type: TABLE DATA; Schema: public; Owner: aurelian
--

COPY public."ContactMessage" (id, name, email, subject, message, "createdAt") FROM stdin;
\.


--
-- Data for Name: NewsletterSubscriber; Type: TABLE DATA; Schema: public; Owner: aurelian
--

COPY public."NewsletterSubscriber" (id, email, "createdAt") FROM stdin;
\.


--
-- Data for Name: Order; Type: TABLE DATA; Schema: public; Owner: aurelian
--

COPY public."Order" (id, number, "userId", email, status, "customerName", "shippingMethod", "shippingPrice", subtotal, total, "paymentMethod", address, "createdAt", "updatedAt") FROM stdin;
cmujlmzsz0003qh597k0yib8o	AW-371543	cmujlmlcu0000qhsga9y93hpe	admin@aurelianwatches.com	pending	Admin One	courier	0	14250	14250	wire	{"zip": "10001", "city": "NYC", "address": "1 Test St", "country": "US"}	2026-09-27 09:11:22.307	2026-09-27 09:11:22.307
cmujlxt7t0001qh9a1a4uxnax	AW-833818	\N	t@t.co	pending	Test Buyer	courier	0	21900	21900	none	{"zip": "1", "city": "NYC", "address": "1 St", "country": "US"}	2026-09-27 09:19:46.985	2026-09-27 09:19:46.985
\.


--
-- Data for Name: OrderItem; Type: TABLE DATA; Schema: public; Owner: aurelian
--

COPY public."OrderItem" (id, "orderId", "watchId", model, reference, brand, qty, price) FROM stdin;
cmujlmzsz0005qh59l72ywu7r	cmujlmzsz0003qh597k0yib8o	rlx-01	Submariner Date	126610LN	rolex	1	14250
cmujlxt7t0003qh9a6b112293	cmujlxt7t0001qh9a1a4uxnax	rlx-02	GMT-Master II "Pepsi"	126710BLRO	rolex	1	21900
\.


--
-- Data for Name: Session; Type: TABLE DATA; Schema: public; Owner: aurelian
--

COPY public."Session" (id, token, "userId", remember, "expiresAt", "createdAt") FROM stdin;
cmujlmld10004qhsg377pfhvb	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJjbXVqbG1sY3UwMDAwcWhzZ2E5eTkzaHBlIiwiaWF0IjoxNzkwNTAwMjYzLCJleHAiOjE3OTMwOTIyNjN9.Og6lEuh9sOyF9tWKNEQ3TaHIS7i6e6Ri9aI0yo-1zgs	cmujlmlcu0000qhsga9y93hpe	t	2026-10-27 09:11:03.589	2026-09-27 09:11:03.59
cmujlmzru0001qh5918shljw4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJjbXVqbG1sY3UwMDAwcWhzZ2E5eTkzaHBlIiwianRpIjoiMGIxZjFiODc3OWEyODU3OGY5ZmI0ZjcxNjMwNGQyOWUiLCJpYXQiOjE3OTA1MDAyODIsImV4cCI6MTc5MzA5MjI4Mn0.S0sRRr9wHUkS-lz3yW2GSoPnkSW84c22gsQQsdWnn3M	cmujlmlcu0000qhsga9y93hpe	t	2026-10-27 09:11:22.266	2026-09-27 09:11:22.267
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: aurelian
--

COPY public."User" (id, name, email, "passwordHash", role, "emailVerifiedAt", "createdAt") FROM stdin;
cmujlmlcu0000qhsga9y93hpe	Admin One	admin@aurelianwatches.com	$2a$10$V9oVN96L9Ss5exPMUl4fnuxlJQ59AZAUbAnZUairbIsopMdAoDFkO	admin	2026-09-27 09:11:03.655	2026-09-27 09:11:03.582
\.


--
-- Data for Name: Watch; Type: TABLE DATA; Schema: public; Owner: aurelian
--

COPY public."Watch" (id, slug, "brandSlug", model, reference, nickname, price, year, type, material, condition, gender, "boxPapers", "isNew", "isFeatured", popularity, "addedAt", description, specs, inventory) FROM stdin;
rlx-03	rolex-datejust-31-two-tone-278273	rolex	Datejust 31	278273	\N	13400	2024	Dress	Yellow gold & Oystersteel	New	Women	t	t	f	78	2025-11-01 00:00:00	The ladies' Datejust in its most classic form: fluted yellow gold bezel, champagne dial and the supple Jubilee bracelet. At 31mm it wears with true jewellery presence without sacrificing everyday robustness.\n\nOffered new and unsized, with the full 2024 Rolex warranty card set.	{"caliber": "Rolex 2236", "bracelet": "Jubilee bracelet, two-tone", "dialColor": "Champagne", "functions": "Hours, minutes, seconds, date", "caseDiameter": "31mm", "caseMaterial": "Yellow gold & Oystersteel", "powerReserve": "55 hours", "waterResistance": "100m"}	1
rlx-04	rolex-daytona-16520-vintage	rolex	Cosmograph Daytona	16520 "Zenith"	\N	38500	1997	Chronograph	Oystersteel	Unworn	Men	t	f	f	88	2025-06-20 00:00:00	The "Zenith" Daytona — powered by the heavily reworked El Primero calibre 4030 — is the bridge between vintage charm and the modern in-house era. This 1997 example bears the coveted inverted-6 dial configuration.\n\nUnpolished case edges, original tritium-lume plots aged to a warm ivory, and its punched guarantee papers.	{"caliber": "Rolex 4030", "bracelet": "Oyster bracelet, Oystersteel", "dialColor": "White", "functions": "Hours, minutes, small seconds, chronograph", "caseDiameter": "40mm", "caseMaterial": "Oystersteel", "powerReserve": "54 hours", "waterResistance": "100m"}	1
rlx-05	rolex-submariner-kermit-16610lv	rolex	Submariner Date "Kermit"	16610LV	Kermit	16800	2004	Dive	Oystersteel	Unworn	Men	t	f	f	90	2025-09-27 00:00:00	The 50th-anniversary Submariner — green aluminium bezel over a maxi dial — earned its Kermit nickname instantly and its classic status since.\n\nA 2004 example with a richly faded insert, solid case and full set.	{"caliber": "Rolex 3135", "bracelet": "Oyster bracelet, Oystersteel", "dialColor": "Black", "functions": "Hours, minutes, seconds, date", "caseDiameter": "40mm", "caseMaterial": "Oystersteel", "powerReserve": "48 hours", "waterResistance": "300m"}	1
rlx-06	rolex-submariner-5513-vintage	rolex	Submariner	5513	\N	19500	1972	Dive	Oystersteel	Unworn	Men	t	f	f	85	2025-03-30 00:00:00	The reference 5513 carried the Submariner through three decades — this 1972 example wears a gorgeous matte dial with tritium plots aged to pumpkin.\n\nFreshly serviced movement, period-correct bezel insert, and a folded Oyster bracelet.	{"caliber": "Rolex 1520", "bracelet": "Folded Oyster bracelet", "dialColor": "Black matte", "functions": "Hours, minutes, seconds", "caseDiameter": "40mm", "caseMaterial": "Oystersteel", "powerReserve": "48 hours", "waterResistance": "200m (as rated)"}	1
rlx-07	rolex-gmt-master-1675-vintage	rolex	GMT-Master "Pepsi"	1675	Pepsi	24500	1968	GMT	Oystersteel	Unworn	Men	t	f	f	87	2025-02-25 00:00:00	The jet-age original — a 1968 GMT-Master with the iconic blue-and-red insert, aged lume and the honest wear of a watch that crossed oceans for a living.\n\nUnpolished case, correct small-hand configuration, service complete.	{"caliber": "Rolex 1570", "bracelet": "Jubilee bracelet, Oystersteel", "dialColor": "Black matte", "functions": "Hours, minutes, seconds, date, GMT", "caseDiameter": "40mm", "caseMaterial": "Oystersteel", "powerReserve": "48 hours", "waterResistance": "50m (as rated)"}	1
rlx-08	rolex-gmt-master-ii-batman-126710blnr	rolex	GMT-Master II "Batman"	126710BLNR	Batman	18900	2024	GMT	Oystersteel	Unworn	Men	t	t	f	96	2025-11-03 00:00:00	The blue-and-black ceramic GMT on Jubilee — the reference every modern traveller wants. Calibre 3285, jumping local hour, seventy-hour reserve.\n\nUnworn 2024 full set with card, hangtags and both links of bracelet sizing.	{"caliber": "Rolex 3285", "bracelet": "Jubilee bracelet, Oystersteel", "dialColor": "Black", "functions": "Hours, minutes, seconds, date, GMT", "caseDiameter": "40mm", "caseMaterial": "Oystersteel", "waterResistance": "100m"}	1
rlx-09	rolex-datejust-36-126234	rolex	Datejust 36	126234	\N	10200	2023	Dress	White gold & Oystersteel	Unworn	Unisex	t	t	f	91	2025-10-15 00:00:00	The Datejust at its most correct: 36mm, fluted white-gold bezel, Jubilee bracelet and the slate Wimbledon dial with green-outlined Romans.\n\n2023 example in near-new condition with the full set.	{"caliber": "Rolex 3235", "bracelet": "Jubilee bracelet", "dialColor": "Slate", "functions": "Hours, minutes, seconds, date", "caseDiameter": "36mm", "caseMaterial": "White gold & Oystersteel", "waterResistance": "100m"}	1
rlx-10	rolex-datejust-36-16233-vintage	rolex	Datejust 36	16233	\N	7850	1993	Dress	Yellow gold & Oystersteel	Unworn	Men	t	f	f	73	2025-04-17 00:00:00	The quintessential nineties Datejust — champagne tapestry dial, fluted yellow-gold bezel, and a tight Jubilee bracelet in two-tone.\n\n1993 example, freshly serviced, with its original punched papers.	{"caliber": "Rolex 3135", "bracelet": "Jubilee bracelet, two-tone", "dialColor": "Champagne tapestry", "functions": "Hours, minutes, seconds, date", "caseDiameter": "36mm", "caseMaterial": "Yellow gold & Oystersteel", "powerReserve": "48 hours", "waterResistance": "100m"}	1
rlx-11	rolex-datejust-41-126300	rolex	Datejust 41	126300	\N	8900	2021	Dress	Oystersteel	Unworn	Unisex	t	f	f	76	2025-05-09 00:00:00	The smooth-bezel Datejust 41 is the quiet daily wearer of the line — mint-green dial, oyster bracelet, calibre 3235.\n\n2021 example with box, papers and very light wear.	{"caliber": "Rolex 3235", "bracelet": "Oyster bracelet, Oystersteel", "dialColor": "Mint green", "functions": "Hours, minutes, seconds, date", "caseDiameter": "41mm", "caseMaterial": "Oystersteel", "waterResistance": "100m"}	1
rlx-12	rolex-lady-datejust-28-279174	rolex	Lady-Datejust 28	279174	\N	9200	2023	Dress	White gold & Oystersteel	Unworn	Women	t	f	f	77	2025-08-19 00:00:00	The Lady-Datejust in its most versatile spec — 28mm steel case, fluted white-gold bezel, silver sunray dial on Jubilee.\n\nUnworn 2023 full set, unsized bracelet.	{"caliber": "Rolex 2236", "bracelet": "Jubilee bracelet", "dialColor": "Silver sunray", "functions": "Hours, minutes, seconds, date", "caseDiameter": "28mm", "caseMaterial": "White gold & Oystersteel", "powerReserve": "55 hours", "waterResistance": "100m"}	1
rlx-02	rolex-gmt-master-ii-pepsi-126710blro	rolex	GMT-Master II "Pepsi"	126710BLRO	Pepsi	21900	2022	GMT	Oystersteel	Unworn	Men	t	f	f	94	2025-08-14 00:00:00	The blue-and-red Cerachrom GMT-Master II on the Jubilee bracelet — the configuration collectors chased from its 2018 return. The calibre 3285 tracks a second time zone with an independently adjustable hour hand.\n\nPresented in unworn condition with crisp case lines, complete set dated 2022.	{"caliber": "Rolex 3285", "bracelet": "Jubilee bracelet, Oystersteel", "dialColor": "Black", "functions": "Hours, minutes, seconds, date, second time zone", "caseDiameter": "40mm", "caseMaterial": "Oystersteel", "waterResistance": "100m"}	0
rlx-13	rolex-daytona-116500ln	rolex	Cosmograph Daytona	116500LN	\N	32500	2022	Chronograph	Oystersteel	Unworn	Men	t	f	t	99	2025-10-09 00:00:00	The white-dial ceramic Daytona — the most demanded reference in the modern catalogue, period. Calibre 4130, Cerachrom bezel, panda registers.\n\n2022 full set in collector-grade condition.	{"caliber": "Rolex 4130", "bracelet": "Oyster bracelet, Oystersteel", "dialColor": "White", "functions": "Hours, minutes, small seconds, chronograph", "caseDiameter": "40mm", "caseMaterial": "Oystersteel", "powerReserve": "72 hours", "waterResistance": "100m"}	1
rlx-14	rolex-daytona-two-tone-116503	rolex	Cosmograph Daytona	116503	\N	21900	2019	Chronograph	Yellow gold & Oystersteel	Unworn	Men	t	f	f	83	2025-06-26 00:00:00	The two-tone Daytona remains the smartest route into the reference — same 4130 calibre, champagne dial, and genuine presence on the wrist.\n\n2019 example, unpolished, complete set.	{"caliber": "Rolex 4130", "bracelet": "Oyster bracelet, two-tone", "dialColor": "Champagne", "functions": "Hours, minutes, small seconds, chronograph", "caseDiameter": "40mm", "caseMaterial": "Yellow gold & Oystersteel", "powerReserve": "72 hours", "waterResistance": "100m"}	1
rlx-15	rolex-day-date-40-228238	rolex	Day-Date 40	228238	\N	44500	2023	Dress	Yellow gold	Unworn	Men	t	f	t	89	2025-10-23 00:00:00	The President in solid yellow gold — fluted bezel, champagne dial, the day spelled in full at twelve and the heft only a gold Rolex delivers.\n\nUnworn 2023 set on the concealed-clasp President bracelet.	{"caliber": "Rolex 3255", "bracelet": "President bracelet, yellow gold", "dialColor": "Champagne", "functions": "Hours, minutes, seconds, day, date", "caseDiameter": "40mm", "caseMaterial": "18k yellow gold", "waterResistance": "100m"}	1
rlx-16	rolex-day-date-36-128235	rolex	Day-Date 36	128235	\N	37500	2022	Dress	Rose gold	Unworn	Unisex	t	f	f	74	2025-07-11 00:00:00	Everose gold and a chocolate dial — the warmest, most discreet Day-Date of the modern line.\n\n2022 example on President bracelet, full set.	{"caliber": "Rolex 3255", "bracelet": "President bracelet, Everose", "dialColor": "Chocolate", "functions": "Hours, minutes, seconds, day, date", "caseDiameter": "36mm", "caseMaterial": "18k Everose gold", "waterResistance": "100m"}	1
rlx-17	rolex-explorer-36-124270	rolex	Explorer 36	124270	\N	7900	2024	Sport	Oystersteel	Unworn	Men	t	t	f	86	2025-11-06 00:00:00	Back to the original 36mm — the Explorer is the purest sports watch Rolex makes: 3-6-9 numerals, no date, nothing to hide behind.\n\nUnworn 2024 full set.	{"caliber": "Rolex 3230", "bracelet": "Oyster bracelet, Oystersteel", "dialColor": "Black", "functions": "Hours, minutes, seconds", "caseDiameter": "36mm", "caseMaterial": "Oystersteel", "waterResistance": "100m"}	1
rlx-18	rolex-explorer-ii-226570	rolex	Explorer II "Polar"	226570	\N	9850	2023	GMT	Oystersteel	Unworn	Men	t	f	f	81	2025-08-05 00:00:00	The polar-dial Explorer II — fixed 24-hour bezel, orange GMT hand and cavern-ready legibility since 1971.\n\n2023 example, very light wear, full set.	{"caliber": "Rolex 3285", "bracelet": "Oyster bracelet, Oystersteel", "dialColor": "White", "functions": "Hours, minutes, seconds, date, 24-hour hand", "caseDiameter": "42mm", "caseMaterial": "Oystersteel", "waterResistance": "100m"}	1
rlx-19	rolex-yacht-master-40-126622	rolex	Yacht-Master 40	126622	\N	14200	2022	Sport	Platinum & Oystersteel	Unworn	Men	t	f	f	75	2025-05-26 00:00:00	The Rolesium Yacht-Master pairs a steel case with a solid platinum bezel — the slate dial catches light like nothing else in the line.\n\n2022 example, complete set.	{"caliber": "Rolex 3235", "bracelet": "Oyster bracelet, Oystersteel", "dialColor": "Slate", "functions": "Hours, minutes, seconds, date", "caseDiameter": "40mm", "caseMaterial": "Platinum & Oystersteel", "waterResistance": "100m"}	1
rlx-20	rolex-sea-dweller-126600	rolex	Sea-Dweller 43	126600	\N	13900	2021	Dive	Oystersteel	Unworn	Men	t	f	f	71	2025-04-06 00:00:00	1,220 metres, helium valve and the red Sea-Dweller signature — the anniversary 43mm that restored the model's proper proportions.\n\n2021 example, full set.	{"caliber": "Rolex 3235", "bracelet": "Oyster bracelet, Oystersteel", "dialColor": "Black", "functions": "Hours, minutes, seconds, date", "caseDiameter": "43mm", "caseMaterial": "Oystersteel", "waterResistance": "1,220m"}	1
rlx-21	rolex-sky-dweller-326934	rolex	Sky-Dweller	326934	\N	21800	2023	GMT	White gold & Oystersteel	Unworn	Men	t	f	f	82	2025-09-03 00:00:00	Rolex's most complicated watch — annual calendar and dual time zones driven by the Ring Command bezel. Blue dial, the collector's pick.\n\nUnworn 2023 full set.	{"caliber": "Rolex 9001", "bracelet": "Oyster bracelet, Oystersteel", "dialColor": "Bright blue", "functions": "Hours, minutes, seconds, date, annual calendar, dual time", "caseDiameter": "42mm", "caseMaterial": "White gold & Oystersteel", "powerReserve": "72 hours", "waterResistance": "100m"}	1
rlx-22	rolex-oyster-perpetual-41-124300	rolex	Oyster Perpetual 41	124300	\N	7600	2024	Sport	Oystersteel	New	Unisex	t	t	f	84	2025-11-09 00:00:00	The OP in the coveted turquoise-blue — three hands, no date, and the most copied dial of the decade.\n\nNew and unsized, 2024 full set.	{"caliber": "Rolex 3230", "bracelet": "Oyster bracelet, Oystersteel", "dialColor": "Turquoise", "functions": "Hours, minutes, seconds", "caseDiameter": "41mm", "caseMaterial": "Oystersteel", "waterResistance": "100m"}	1
rlx-23	rolex-air-king-126900	rolex	Air-King	126900	\N	7100	2023	Pilot	Oystersteel	Unworn	Men	t	f	f	68	2025-06-15 00:00:00	The redesigned Air-King — crown guards, luminous 3-6-9, and the bold minute track lifted straight from a cockpit dial.\n\n2023 example with the full set.	{"caliber": "Rolex 3230", "bracelet": "Oyster bracelet, Oystersteel", "dialColor": "Black", "functions": "Hours, minutes, seconds", "caseDiameter": "40mm", "caseMaterial": "Oystersteel", "waterResistance": "100m"}	1
rlx-24	rolex-milgauss-116400gv	rolex	Milgauss GV	116400GV	\N	11200	2020	Sport	Oystersteel	Unworn	Men	t	f	f	70	2025-03-12 00:00:00	The scientist's Rolex — anti-magnetic shielding to a thousand gauss, the green Glace Verte crystal and the lightning-bolt seconds hand.\n\nDiscontinued 2020 example, full set, excellent condition.	{"caliber": "Rolex 3131", "bracelet": "Oyster bracelet, Oystersteel", "dialColor": "Z-blue", "functions": "Hours, minutes, seconds", "caseDiameter": "40mm", "caseMaterial": "Oystersteel", "powerReserve": "48 hours", "waterResistance": "100m"}	1
pp-01	patek-philippe-nautilus-5711-1a	patek-philippe	Nautilus	5711/1A-010	\N	135000	2019	Sport	Stainless steel	Unworn	Men	t	f	t	97	2025-09-05 00:00:00	Discontinued in 2021, the blue-dial 5711/1A became the single most sought-after steel sports watch of its generation. Gérald Genta's porthole silhouette and the horizontally embossed dial need no introduction.\n\nA 2019 full set in superb condition — the centrepiece of any serious collection.	{"caliber": "Patek Philippe 26-330 S C", "bracelet": "Integrated steel bracelet", "dialColor": "Blue gradated", "functions": "Hours, minutes, seconds, date", "caseDiameter": "40mm", "caseMaterial": "Stainless steel", "powerReserve": "45 hours", "waterResistance": "120m"}	1
pp-02	patek-philippe-aquanaut-5167a	patek-philippe	Aquanaut	5167A-001	\N	62000	2021	Sport	Stainless steel	Unworn	Men	t	f	f	90	2025-07-30 00:00:00	The Aquanaut distilled the Nautilus idea into a younger, sportier register — embossed black dial, luminous Arabic numerals and the "Tropical" composite strap that shrugs off water and heat.\n\nThis 2021 example presents close to new with complete accessories.	{"caliber": "Patek Philippe 26-330 S C", "bracelet": "Tropical composite strap", "dialColor": "Black embossed", "functions": "Hours, minutes, seconds, date", "caseDiameter": "40.8mm", "caseMaterial": "Stainless steel", "powerReserve": "45 hours", "waterResistance": "120m"}	1
pp-03	patek-philippe-calatrava-6119r	patek-philippe	Calatrava	6119R-001	\N	32500	2023	Dress	Rose gold	Unworn	Men	t	t	f	74	2025-10-25 00:00:00	The quintessential dress watch. The 6119R revives the Clous de Paris hobnail bezel in rose gold around a silvery grained dial — a direct line to the Calatravas of 1932.\n\nUnworn, complete set, dated 2023.	{"caliber": "Patek Philippe 30-255 PS", "bracelet": "Brown alligator strap", "dialColor": "Silver grained", "functions": "Hours, minutes, small seconds", "caseDiameter": "39mm", "caseMaterial": "Rose gold", "powerReserve": "65 hours", "waterResistance": "30m"}	1
pp-04	patek-philippe-twenty-4-4910-10a	patek-philippe	Twenty~4	4910/10A-011	\N	14800	2020	Dress	Stainless steel	Unworn	Women	t	f	f	62	2025-05-11 00:00:00	The Twenty~4 manchette has been Patek's definitive ladies' piece for two decades — a diamond-set steel cuff that reads as jewellery first and timepiece second.\n\nThis 2020 quartz example is offered with box, papers and a fresh service seal.	{"caliber": "Patek Philippe E15", "bracelet": "Integrated steel manchette", "movement": "Quartz", "dialColor": "Olive sunburst", "functions": "Hours, minutes", "caseDiameter": "25.1 × 30mm", "caseMaterial": "Stainless steel, diamond-set", "powerReserve": "—", "waterResistance": "30m"}	1
ap-01	audemars-piguet-royal-oak-15500st	audemars-piguet	Royal Oak Selfwinding	15500ST.OO.1220ST.01	\N	38500	2020	Sport	Stainless steel	Unworn	Men	t	f	t	93	2025-09-18 00:00:00	The 15500ST is the Royal Oak at its purest: 41mm of brushed steel, the octagonal bezel with its eight white-gold screws, and the slate-grey Grande Tapisserie dial.\n\nSharp, unpolished and complete with its 2020 warranty — the integrated-bracelet icon in its definitive modern form.	{"caliber": "AP 4302", "bracelet": "Integrated steel bracelet", "dialColor": "Grey Grande Tapisserie", "functions": "Hours, minutes, seconds, date", "caseDiameter": "41mm", "caseMaterial": "Stainless steel", "waterResistance": "50m"}	1
ap-02	audemars-piguet-royal-oak-offshore-26470st	audemars-piguet	Royal Oak Offshore Chronograph	26470ST.OO.A101CR.01	\N	29800	2018	Chronograph	Stainless steel	Unworn	Men	t	f	f	80	2025-04-08 00:00:00	The Offshore took Genta's design and turned the volume up — 42mm, ceramic pushers, and a Méga Tapisserie dial built for the wrist of a racing driver.\n\nThis 2018 "Safari" variant pairs the ivory dial with a brown hornback alligator strap.	{"caliber": "AP 3126/3840", "bracelet": "Hornback alligator strap", "dialColor": "Ivory", "functions": "Hours, minutes, small seconds, date, chronograph", "caseDiameter": "42mm", "caseMaterial": "Stainless steel", "powerReserve": "50 hours", "waterResistance": "100m"}	1
ap-03	audemars-piguet-royal-oak-jumbo-15202st	audemars-piguet	Royal Oak "Jumbo" Extra-Thin	15202ST.OO.1240ST.01	\N	68500	2017	Dress	Stainless steel	Unworn	Men	t	f	f	91	2025-10-30 00:00:00	The watch Genta drew in one night, rendered 8.1mm thin. The 15202's Petite Tapisserie blue dial and hand-finished calibre 2121 make it the connoisseur's Royal Oak.\n\nArriving shortly — register your interest with our concierge team.	{"caliber": "AP 2121", "bracelet": "Integrated steel bracelet", "dialColor": "Blue Petite Tapisserie", "functions": "Hours, minutes, date", "caseDiameter": "39mm", "caseMaterial": "Stainless steel", "powerReserve": "40 hours", "waterResistance": "50m"}	1
ap-04	audemars-piguet-code-1159-15210bc	audemars-piguet	Code 11.59 Selfwinding	15210BC.OO.A068CR.01	\N	26500	2022	Dress	White gold	Unworn	Men	t	f	f	55	2025-03-19 00:00:00	Code 11.59 is AP's architectural counterpoint to the Royal Oak — a round white-gold case hiding an octagonal middle, under a double-curved sapphire.\n\nThis smoked grey lacquer dial example is one of the most wearable executions, offered with its 2022 set.	{"caliber": "AP 4302", "bracelet": "Grey alligator strap", "dialColor": "Smoked grey lacquer", "functions": "Hours, minutes, seconds, date", "caseDiameter": "41mm", "caseMaterial": "White gold", "waterResistance": "30m"}	1
rm-01	richard-mille-rm-011-felipe-massa	richard-mille	RM 011 Flyback Chronograph	RM 011 AJ Ti	\N	265000	2016	Chronograph	Titanium	Unworn	Men	t	f	t	89	2025-08-22 00:00:00	The Felipe Massa flyback that put Richard Mille on the map — a skeletonised annual-calendar chronograph inside a curved tonneau titanium case weighing almost nothing.\n\nFull 2016 set with service records; inspected and pressure-tested by our watchmakers.	{"caliber": "RMAC1", "bracelet": "Black rubber strap", "dialColor": "Skeleton", "functions": "Flyback chronograph, annual calendar", "caseDiameter": "50 × 40mm", "caseMaterial": "Grade 5 titanium", "powerReserve": "55 hours", "waterResistance": "50m"}	1
rm-02	richard-mille-rm-035-rafael-nadal	richard-mille	RM 035 "Baby Nadal"	RM 035 CA	\N	310000	2015	Sport	ALUSIC	Unworn	Men	t	f	f	84	2025-06-12 00:00:00	Built to survive Rafael Nadal's forehand, the RM 035 shrugs off shocks above 5,000 g in an ALUSIC case that registers barely 4.3 grams of movement.\n\nAn exceptionally clean 2015 example — among the lightest mechanical watches ever produced at scale.	{"caliber": "RMUL1", "bracelet": "Textile strap", "movement": "Manual winding", "dialColor": "Skeleton", "functions": "Hours, minutes, seconds", "caseDiameter": "48 × 39.7mm", "caseMaterial": "ALUSIC", "powerReserve": "55 hours", "waterResistance": "50m"}	1
rm-03	richard-mille-rm-055-bubba-watson	richard-mille	RM 055 "Bubba Watson"	RM 055 Ti	\N	395000	2019	Sport	Titanium	Unworn	Men	t	f	f	82	2025-09-28 00:00:00	The Bubba Watson edition pairs a grade-5 titanium case with a skeletonised movement suspended on a shock-resistant baseplate — engineering born of golf swings, not jewellers' benches.\n\nOffered with certificate and presentation box, 2019.	{"caliber": "RMUL2", "bracelet": "White rubber strap", "movement": "Manual winding", "dialColor": "Skeleton", "functions": "Hours, minutes, seconds", "caseDiameter": "49.9 × 42.7mm", "caseMaterial": "Titanium", "powerReserve": "55 hours", "waterResistance": "30m"}	1
rm-04	richard-mille-rm-67-02-sprint	richard-mille	RM 67-02 Extra Flat	RM 67-02 CA	\N	285000	2021	Sport	Carbon TPT	Unworn	Men	t	f	f	79	2025-11-05 00:00:00	At 32 grams on its seamless elastic strap, the RM 67-02 is a watch you forget you are wearing — until the marbled Carbon TPT catches the light.\n\nIncoming unworn example; concierge allocation by enquiry.	{"caliber": "CRMA7", "bracelet": "Elastic textile strap", "dialColor": "Skeleton", "functions": "Hours, minutes", "caseDiameter": "47.25 × 38.7mm", "caseMaterial": "Carbon TPT", "powerReserve": "50 hours", "waterResistance": "30m"}	1
om-01	omega-speedmaster-moonwatch-31030425001001	omega	Speedmaster Moonwatch Professional	310.30.42.50.01.001	\N	6850	2024	Chronograph	Stainless steel	Unworn	Men	t	t	t	95	2025-10-08 00:00:00	The Moonwatch — flight-qualified by NASA and still the only watch worn on the lunar surface. This current-production example carries the Co-Axial Master Chronometer calibre 3861.\n\nUnworn on its flat-link bracelet with the full 2024 set.	{"caliber": "Omega 3861", "bracelet": "Steel flat-link bracelet", "movement": "Manual winding", "dialColor": "Black", "functions": "Hours, minutes, small seconds, chronograph", "caseDiameter": "42mm", "caseMaterial": "Stainless steel", "powerReserve": "50 hours", "waterResistance": "50m"}	1
om-02	omega-seamaster-diver-300m-21030422003001	omega	Seamaster Diver 300M	210.30.42.20.03.001	\N	4650	2022	Dive	Stainless steel	Unworn	Men	t	f	f	86	2025-05-27 00:00:00	The wave-dial Seamaster — 25 years of 007 pedigree in a watch that simply refuses to age. Blue ceramic bezel, laser-engraved dial and the Master Chronometer 8800.\n\nLight wear consistent with occasional use; complete set.	{"caliber": "Omega 8800", "bracelet": "Steel bracelet", "dialColor": "Blue ceramic", "functions": "Hours, minutes, seconds, date, helium escape valve", "caseDiameter": "42mm", "caseMaterial": "Stainless steel", "powerReserve": "55 hours", "waterResistance": "300m"}	1
om-03	omega-constellation-13110292055001	omega	Constellation	131.10.29.20.55.001	\N	6400	2023	Dress	Stainless steel	New	Women	t	t	f	60	2025-10-19 00:00:00	The 29mm Constellation frames a mother-of-pearl dial within the collection's signature polished claws — an elegant daily watch with genuine mechanical depth via the calibre 8700.\n\nNew and unworn, full 2023 warranty.	{"caliber": "Omega 8700", "bracelet": "Steel mono-rang bracelet", "dialColor": "White mother-of-pearl", "functions": "Hours, minutes, seconds, date", "caseDiameter": "29mm", "caseMaterial": "Stainless steel", "powerReserve": "50 hours", "waterResistance": "50m"}	1
om-04	omega-seamaster-300-vintage-165024	omega	Seamaster 300	165.024	\N	11500	1968	Dive	Stainless steel	Unworn	Men	t	f	f	72	2025-02-14 00:00:00	The military-issue Seamaster 300 — broad-arrow hands, bakelite-style bezel and the luminous dial once strapped to Royal Navy divers. A cornerstone of vintage Omega collecting.\n\nHonest 1968 example with original dial, service history and extract from the archives.	{"caliber": "Omega 552", "bracelet": "NATO-style strap", "dialColor": "Black matte", "functions": "Hours, minutes, seconds, date", "caseDiameter": "41.5mm", "caseMaterial": "Stainless steel", "powerReserve": "50 hours", "waterResistance": "200m (as rated)"}	1
car-01	cartier-santos-wssa0018	cartier	Santos de Cartier	WSSA0018	\N	7250	2022	Sport	Stainless steel	Unworn	Men	t	f	t	85	2025-07-07 00:00:00	Created in 1904 for aviator Alberto Santos-Dumont, the modern Santos keeps the square case and exposed screws while adding the QuickSwitch strap system and SmartLink sizing.\n\nA 2022 large model with both bracelet and leather strap included.	{"caliber": "Cartier 1847 MC", "bracelet": "Steel bracelet + leather strap", "dialColor": "Silvered opaline", "functions": "Hours, minutes, seconds, date", "caseDiameter": "39.8mm", "caseMaterial": "Stainless steel", "powerReserve": "42 hours", "waterResistance": "100m"}	1
car-02	cartier-tank-must-wsta0041	cartier	Tank Must	WSTA0041	\N	3100	2023	Dress	Stainless steel	New	Women	t	t	f	81	2025-10-12 00:00:00	The Tank has barely changed since 1917 because it never needed to. The large Tank Must distils the design to its essence — silvered dial, blued sword hands, beaded crown with blue cabochon.\n\nBrand new on black grained calfskin with the full Cartier set.	{"caliber": "Cartier quartz", "bracelet": "Black grained calfskin", "movement": "Quartz", "dialColor": "Silvered", "functions": "Hours, minutes", "caseDiameter": "33.7 × 25.5mm", "caseMaterial": "Stainless steel", "powerReserve": "—", "waterResistance": "30m"}	1
car-03	cartier-panthere-wgpn0007	cartier	Panthère de Cartier	WGPN0007	\N	21900	2021	Dress	Yellow gold	Unworn	Women	t	f	f	76	2025-04-29 00:00:00	Supple as jewellery, unmistakable as a Tank's cousin — the Panthère in 18k yellow gold moves like liquid on the wrist.\n\nA small-model example from 2021, fully serviced and presented with its Cartier pouch and papers.	{"caliber": "Cartier quartz", "bracelet": "Gold link bracelet", "movement": "Quartz", "dialColor": "Silvered", "functions": "Hours, minutes", "caseDiameter": "22mm", "caseMaterial": "18k yellow gold", "powerReserve": "—", "waterResistance": "30m"}	1
car-04	cartier-santos-dumont-vintage-1575	cartier	Santos-Dumont	1575	\N	9800	1998	Dress	Yellow gold	Unworn	Men	t	f	f	66	2025-01-30 00:00:00	An ultra-thin yellow gold Santos-Dumont from the late nineties — the dressiest expression of the aviation original, barely 5mm at the case.\n\nCrisp guilloché dial, correct cabochon crown, and a fresh Cartier service.	{"caliber": "Cartier 06 (manual)", "bracelet": "Bordeaux alligator strap", "movement": "Manual winding", "dialColor": "Silvered guilloché", "functions": "Hours, minutes", "caseDiameter": "27 × 36mm", "caseMaterial": "18k yellow gold", "powerReserve": "40 hours", "waterResistance": "30m"}	1
br-01	breitling-navitimer-b01-41-ab0139211l1a1	breitling	Navitimer B01 Chronograph 41	AB0139211L1A1	\N	8400	2023	Chronograph	Stainless steel	Unworn	Men	t	f	f	78	2025-08-03 00:00:00	The pilot's chronograph that started it all — circular slide rule, in-house B01 movement, and the emerald green dial of the 2022 redesign.\n\nNear-new 2023 example on the seven-row bracelet.	{"caliber": "Breitling B01", "bracelet": "Steel seven-row bracelet", "dialColor": "Green", "functions": "Hours, minutes, small seconds, date, chronograph, slide rule", "caseDiameter": "41mm", "caseMaterial": "Stainless steel", "waterResistance": "30m"}	1
br-02	breitling-superocean-heritage-57	breitling	Superocean Heritage '57	A10370121C1A1	\N	4600	2021	Dive	Stainless steel	Unworn	Men	t	f	f	68	2025-03-09 00:00:00	A faithful nod to the original 1957 Superocean — concave bezel, oversized indices and sea-blue dial in a slim 42mm case.\n\nExcellent 2021 example on the mesh Ocean Classic bracelet.	{"caliber": "Breitling 10", "bracelet": "Steel mesh bracelet", "dialColor": "Blue", "functions": "Hours, minutes, seconds", "caseDiameter": "42mm", "caseMaterial": "Stainless steel", "powerReserve": "42 hours", "waterResistance": "100m"}	1
br-03	breitling-chronomat-b01-42	breitling	Chronomat B01 42	AB0134101K1A1	\N	7150	2022	Chronograph	Stainless steel	Unworn	Men	t	f	f	70	2025-06-05 00:00:00	The Chronomat's onion crown and rider tabs made it the watch of the eighties jet set; the current B01 generation keeps the swagger and adds a manufacture movement.\n\nAnthracite dial, Rouleaux bracelet, 2022 set.	{"caliber": "Breitling B01", "bracelet": "Steel Rouleaux bracelet", "dialColor": "Anthracite", "functions": "Hours, minutes, small seconds, date, chronograph", "caseDiameter": "42mm", "caseMaterial": "Stainless steel", "waterResistance": "200m"}	1
br-04	breitling-premier-b09-pistachio	breitling	Premier B09 Chronograph 40	AB0930D31L1P1	\N	7950	2024	Dress	Stainless steel	New	Men	t	t	f	58	2025-11-02 00:00:00	The Premier's pistachio-green dial is one of the great quiet flexes of modern watchmaking — a hand-wound 1940s-style chronograph for people who notice details.\n\nNew on brown alligator with the full 2024 warranty.	{"caliber": "Breitling B09", "bracelet": "Brown alligator strap", "movement": "Manual winding", "dialColor": "Pistachio green", "functions": "Hours, minutes, small seconds, chronograph", "caseDiameter": "40mm", "caseMaterial": "Stainless steel", "waterResistance": "100m"}	1
tag-01	tag-heuer-carrera-glassbox-cbs2210	tag-heuer	Carrera Chronograph "Glassbox"	CBS2210.FC6534	\N	6100	2024	Chronograph	Stainless steel	Unworn	Men	t	t	f	77	2025-10-28 00:00:00	The Glassbox reissue nails the 1963 Carrera — domed sapphire flowing over a panda dial with the flange-mounted tachymeter, powered by the in-house TH20-00.\n\nUnworn 2024 example on perforated black leather.	{"caliber": "TAG Heuer TH20-00", "bracelet": "Black perforated leather strap", "dialColor": "Silver panda", "functions": "Hours, minutes, small seconds, date, chronograph", "caseDiameter": "39mm", "caseMaterial": "Stainless steel", "waterResistance": "100m"}	1
tag-02	tag-heuer-monaco-caw211p	tag-heuer	Monaco Calibre 11	CAW211P.FC6356	\N	6450	2021	Chronograph	Stainless steel	Unworn	Men	t	f	f	82	2025-05-16 00:00:00	The square watch that Steve McQueen made immortal — left-hand crown, metallic blue dial, and the Calibre 11 descended from the first automatic chronograph.\n\nA 2021 example on its perforated rally strap, complete set.	{"caliber": "TAG Heuer Calibre 11", "bracelet": "Blue perforated leather strap", "dialColor": "Blue sunray", "functions": "Hours, minutes, small seconds, date, chronograph", "caseDiameter": "39mm", "caseMaterial": "Stainless steel", "powerReserve": "40 hours", "waterResistance": "100m"}	1
tag-03	tag-heuer-aquaracer-wbp201b	tag-heuer	Aquaracer Professional 300	WBP201B.BA0632	\N	3250	2023	Dive	Stainless steel	Unworn	Men	t	f	f	64	2025-07-22 00:00:00	The modern Aquaracer is a serious tool watch — 300 metres, ceramic 12-sided bezel, and the orange-accented seconds hand recalling the original 844.\n\nGreen sunray dial, 2023, very light wear.	{"caliber": "TAG Heuer Calibre 5", "bracelet": "Steel bracelet, diver extension", "dialColor": "Green sunray", "functions": "Hours, minutes, seconds, date", "caseDiameter": "43mm", "caseMaterial": "Stainless steel", "powerReserve": "38 hours", "waterResistance": "300m"}	1
tag-04	tag-heuer-carrera-date-wbn2311	tag-heuer	Carrera Date 36	WBN2311.BA0001	\N	2750	2022	Sport	Stainless steel	Unworn	Women	t	f	f	52	2025-02-27 00:00:00	The 36mm Carrera Date brings the racing collection's clean legibility to a smaller wrist — silver dial, applied indices, effortless daily versatility.\n\nPresented in unworn condition, timed and sealed by our watchmakers.	{"caliber": "TAG Heuer Calibre 7", "bracelet": "Steel bracelet", "dialColor": "Silver", "functions": "Hours, minutes, seconds, date", "caseDiameter": "36mm", "caseMaterial": "Stainless steel", "powerReserve": "50 hours", "waterResistance": "50m"}	1
tud-01	tudor-black-bay-58-79030n	tudor	Black Bay Fifty-Eight	79030N-0001	\N	3650	2023	Dive	Stainless steel	Unworn	Men	t	f	t	88	2025-09-09 00:00:00	A love letter to Tudor's 1958 divers — gilt accents, red-tipped bezel and a 39mm case that fits like a vintage original, powered by the in-house MT5402.\n\nComplete 2023 set, presented unworn.	{"caliber": "Tudor MT5402", "bracelet": "Steel riveted bracelet", "dialColor": "Black, gilt", "functions": "Hours, minutes, seconds", "caseDiameter": "39mm", "caseMaterial": "Stainless steel", "waterResistance": "200m"}	1
tud-02	tudor-black-bay-gmt-79830rb	tudor	Black Bay GMT "Pepsi"	79830RB-0001	\N	4150	2022	GMT	Stainless steel	Unworn	Men	t	f	f	80	2025-06-18 00:00:00	Tudor's burgundy-and-blue GMT offers the Rolex-family travel watch at a fraction of the price — with a true jumping local hour and 70-hour reserve.\n\nWell-kept 2022 example on its riveted steel bracelet.	{"caliber": "Tudor MT5652", "bracelet": "Steel riveted bracelet", "dialColor": "Black", "functions": "Hours, minutes, seconds, date, GMT", "caseDiameter": "41mm", "caseMaterial": "Stainless steel", "waterResistance": "200m"}	1
tud-03	tudor-pelagos-39-25407n	tudor	Pelagos 39	25407N-0001	\N	4350	2024	Dive	Titanium	New	Men	t	t	f	74	2025-10-30 00:00:00	The Pelagos distilled to its perfect size: 39mm of grade-2 titanium, fully matte, with the effortless legibility that made the line a professional favourite.\n\nBrand new 2024 set on bracelet plus rubber strap.	{"caliber": "Tudor MT5400", "bracelet": "Titanium bracelet + rubber strap", "dialColor": "Black matte", "functions": "Hours, minutes, seconds", "caseDiameter": "39mm", "caseMaterial": "Grade 2 titanium", "waterResistance": "200m"}	1
tud-04	tudor-prince-oysterdate-vintage-74034	tudor	Prince Oysterdate	74034	\N	2950	1995	Dress	Stainless steel	Unworn	Men	t	f	f	49	2025-01-22 00:00:00	A mid-nineties Prince Oysterdate — Rolex-built case, self-winding ETA heart, and the quiet charm of a watch that simply does everything right.\n\nOriginal silver dial, service crown and a fresh overhaul; a charming entry into vintage Tudor.	{"caliber": "ETA 2824-2", "bracelet": "Steel Oyster-style bracelet", "dialColor": "Silver", "functions": "Hours, minutes, seconds, date", "caseDiameter": "34mm", "caseMaterial": "Stainless steel", "powerReserve": "38 hours", "waterResistance": "100m (as rated)"}	1
hub-01	hublot-big-bang-unico-441	hublot	Big Bang Unico 42	441.NX.1170.RX	\N	18500	2021	Chronograph	Titanium	Unworn	Men	t	f	f	71	2025-07-15 00:00:00	The Big Bang Unico puts its flyback chronograph calibre on full display through an openworked dial — Hublot's fusion philosophy rendered in titanium.\n\nCrisp 2021 example on the structured rubber strap.	{"caliber": "Hublot HUB1280", "bracelet": "Black structured rubber", "dialColor": "Matte black openworked", "functions": "Hours, minutes, small seconds, date, flyback chronograph", "caseDiameter": "42mm", "caseMaterial": "Titanium", "powerReserve": "72 hours", "waterResistance": "100m"}	1
hub-02	hublot-classic-fusion-511	hublot	Classic Fusion Titanium	511.NX.1171.LR	\N	6500	2020	Dress	Titanium	Unworn	Men	t	f	f	57	2025-04-02 00:00:00	The Classic Fusion pares the porthole design back to an elegant 45mm daily watch — satin titanium case over a black sunray dial, rubber-lined leather strap.\n\nWell-kept 2020 example with box and papers.	{"caliber": "Hublot HUB11", "bracelet": "Leather on rubber strap", "dialColor": "Black sunray", "functions": "Hours, minutes, seconds, date", "caseDiameter": "45mm", "caseMaterial": "Titanium", "powerReserve": "42 hours", "waterResistance": "50m"}	1
hub-03	hublot-spirit-of-big-bang-601	hublot	Spirit of Big Bang	601.NM.0173.LR	\N	19800	2019	Chronograph	Titanium & ceramic	Unworn	Men	t	f	f	63	2025-03-25 00:00:00	The tonneau-shaped Spirit takes the Big Bang's architecture and stretches it into a bolder silhouette — ceramic bezel, skeleton dial and Unico-derived chronograph.\n\nA strong 2019 example; case and crystal in excellent order.	{"caliber": "Hublot HUB4700", "bracelet": "Leather on rubber strap", "dialColor": "Skeleton", "functions": "Hours, minutes, small seconds, date, chronograph", "caseDiameter": "45mm", "caseMaterial": "Titanium & black ceramic", "powerReserve": "50 hours", "waterResistance": "100m"}	1
hub-04	hublot-big-bang-king-gold-301	hublot	Big Bang King Gold 41	341.PX.130.RX	\N	27900	2018	Chronograph	King Gold	Unworn	Men	t	f	f	60	2025-02-08 00:00:00	Hublot's proprietary King Gold — richer than standard 5N — gives the 41mm Big Bang genuine warmth against its black ceramic bezel.\n\nFully serviced 2018 example with a recent pressure test and paperwork.	{"caliber": "Hublot HUB4300", "bracelet": "Black rubber strap", "dialColor": "Black carbon", "functions": "Hours, minutes, small seconds, date, chronograph", "caseDiameter": "41mm", "caseMaterial": "18k King Gold", "powerReserve": "42 hours", "waterResistance": "100m"}	1
iwc-01	iwc-portugieser-chronograph-371605	iwc	Portugieser Chronograph	IW371605	\N	7900	2022	Chronograph	Stainless steel	Unworn	Men	t	f	t	83	2025-08-27 00:00:00	The vertical two-register Portugieser — arguably the most handsome production chronograph made — now with the in-house 69355 visible through the sapphire back.\n\nBlue-on-silver dial, 2022, complete set.	{"caliber": "IWC 69355", "bracelet": "Black alligator strap", "dialColor": "Silver-plated, blue hands", "functions": "Hours, minutes, small seconds, chronograph", "caseDiameter": "41mm", "caseMaterial": "Stainless steel", "waterResistance": "30m"}	1
iwc-02	iwc-pilots-mark-xx-328201	iwc	Pilot's Watch Mark XX	IW328201	\N	4950	2023	Pilot	Stainless steel	Unworn	Men	t	f	f	79	2025-09-14 00:00:00	The direct descendant of the 1948 Mark 11 navigators' watch — soft-iron cage, anti-reflective crystal secured against pressure drop, now with 120-hour calibre 32111.\n\nBlack dial on EasX-CHANGE bracelet, 2023 set.	{"caliber": "IWC 32111", "bracelet": "Steel bracelet", "dialColor": "Black", "functions": "Hours, minutes, seconds, date", "caseDiameter": "40mm", "caseMaterial": "Stainless steel", "powerReserve": "120 hours", "waterResistance": "100m"}	1
iwc-03	iwc-portofino-iw356502	iwc	Portofino Automatic	IW356502	\N	4450	2019	Dress	Stainless steel	Unworn	Men	t	f	f	61	2025-05-04 00:00:00	The Portofino's round, leaf-handed simplicity channels the dolce vita of the Italian Riviera — a dress watch that never tries too hard.\n\nSilver dial on black Santoni alligator; presented unworn with a fresh service seal.	{"caliber": "IWC 35111", "bracelet": "Black Santoni alligator", "dialColor": "Silver-plated", "functions": "Hours, minutes, seconds, date", "caseDiameter": "40mm", "caseMaterial": "Stainless steel", "powerReserve": "42 hours", "waterResistance": "30m"}	1
iwc-04	iwc-portugieser-automatic-500705	iwc	Portugieser Automatic 40	IW358304	\N	7350	2021	Dress	Stainless steel	Unworn	Men	t	f	f	65	2025-06-29 00:00:00	A 40mm Portugieser with small seconds at six — the marine-chronometer layout of the 1939 original in a case sized for modern wrists.\n\nSalmon-toned dial, 2021, excellent throughout.	{"caliber": "IWC 82200", "bracelet": "Black alligator strap", "dialColor": "Salmon", "functions": "Hours, minutes, small seconds", "caseDiameter": "40.4mm", "caseMaterial": "Stainless steel", "waterResistance": "30m"}	1
pan-01	panerai-luminor-marina-pam01312	panerai	Luminor Marina 1950 3 Days	PAM01312	\N	7300	2021	Dive	Stainless steel	Unworn	Men	t	f	f	75	2025-07-02 00:00:00	The crown-protecting bridge, the cushion case, the sandwich dial — everything Panerai in 44mm, powered by the in-house P.9010 with twin barrels.\n\nComplete 2021 set on the black calf strap with spare rubber.	{"caliber": "Panerai P.9010", "bracelet": "Black calf strap", "dialColor": "Black sandwich", "functions": "Hours, minutes, small seconds, date", "caseDiameter": "44mm", "caseMaterial": "AISI 316L steel", "powerReserve": "72 hours", "waterResistance": "300m"}	1
pan-02	panerai-luminor-due-pam01249	panerai	Luminor Due 38	PAM01249	\N	6400	2022	Dress	Stainless steel	Unworn	Women	t	f	f	58	2025-04-21 00:00:00	The Luminor Due translates Panerai's instrument-watch DNA into a slim, polished 38mm that slips under a cuff — the marque's most versatile line.\n\nIvory dial, gold hands, 2022 full set.	{"caliber": "Panerai P.900", "bracelet": "Beige alligator strap", "dialColor": "Ivory sun-brushed", "functions": "Hours, minutes, small seconds, date", "caseDiameter": "38mm", "caseMaterial": "Polished steel", "powerReserve": "72 hours", "waterResistance": "50m"}	1
pan-03	panerai-submersible-pam00959	panerai	Submersible 42	PAM00959	\N	8400	2020	Dive	Stainless steel	Unworn	Men	t	f	f	66	2025-03-15 00:00:00	The proper dive Panerai — unidirectional ceramic bezel, 300-metre rating and the op-blue ceramic dial shifting between navy and near-black.\n\n2020 example on Caoutchouc rubber, serviced.	{"caliber": "Panerai P.900", "bracelet": "Blue Caoutchouc rubber", "dialColor": "Blue ceramic", "functions": "Hours, minutes, small seconds, date", "caseDiameter": "42mm", "caseMaterial": "AISI 316L steel", "powerReserve": "72 hours", "waterResistance": "300m"}	1
pan-04	panerai-radiomir-vintage-pam00380	panerai	Radiomir Black Seal Logo	PAM00380	\N	4900	2012	Dive	Stainless steel	Unworn	Men	t	f	f	54	2025-01-12 00:00:00	The wire-lugged Radiomir in its purest form — hand-wound, no seconds, the double-torch OP logo at six. A purist's Panerai.\n\n2012 example, fully serviced with two-year warranty.	{"caliber": "Panerai OP II", "bracelet": "Black calf strap", "movement": "Manual winding", "dialColor": "Black sandwich", "functions": "Hours, minutes", "caseDiameter": "45mm", "caseMaterial": "Polished steel", "powerReserve": "56 hours", "waterResistance": "100m"}	1
jlc-01	jaeger-lecoultre-reverso-tribute-3978480	jaeger-lecoultre	Reverso Tribute Small Seconds	Q3978480	\N	9200	2023	Dress	Stainless steel	Unworn	Men	t	f	t	81	2025-09-20 00:00:00	Flip the case and the 1931 art-deco icon reveals its blank canvas — the Reverso remains the most elegant idea in watch design. This Tribute wears the deep blue dial of the modern classic.\n\nComplete 2023 set on Casa Fagliano-style strap.	{"caliber": "JLC 822/2", "bracelet": "Blue calf Fagliano strap", "movement": "Manual winding", "dialColor": "Blue sunray", "functions": "Hours, minutes, small seconds", "caseDiameter": "45.6 × 27.4mm", "caseMaterial": "Stainless steel", "powerReserve": "42 hours", "waterResistance": "30m"}	1
jlc-02	jaeger-lecoultre-master-ultra-thin-1368420	jaeger-lecoultre	Master Ultra Thin Date	Q1368420	\N	8100	2020	Dress	Stainless steel	Unworn	Men	t	f	f	67	2025-05-30 00:00:00	Under 8mm thick with a full date and 70-hour reserve, the Master Ultra Thin is the dress watch's quiet overachiever.\n\nSilver sunray dial, 2020, excellent condition throughout.	{"caliber": "JLC 899", "bracelet": "Black alligator strap", "dialColor": "Silver sunray", "functions": "Hours, minutes, seconds, date", "caseDiameter": "39mm", "caseMaterial": "Stainless steel", "powerReserve": "70 hours", "waterResistance": "50m"}	1
jlc-03	jaeger-lecoultre-polaris-9068670	jaeger-lecoultre	Polaris Date	Q9068670	\N	7800	2021	Sport	Stainless steel	Unworn	Men	t	f	f	59	2025-06-08 00:00:00	The Polaris revives JLC's 1968 diver-alarm line as a refined daily sports watch — rotating inner bezel, twin crowns, and a vanilla-tinted lume nod to the original.\n\nBlue gradient dial, 2021, complete.	{"caliber": "JLC 899A/1", "bracelet": "Steel bracelet + rubber strap", "dialColor": "Blue gradient", "functions": "Hours, minutes, seconds, date, inner rotating bezel", "caseDiameter": "42mm", "caseMaterial": "Stainless steel", "waterResistance": "200m"}	1
jlc-04	jaeger-lecoultre-reverso-classique-vintage-250886	jaeger-lecoultre	Reverso Classique	250.8.86	\N	5400	2003	Dress	Stainless steel	Unworn	Unisex	t	f	f	56	2025-02-01 00:00:00	A mid-size Reverso Classique from 2003 — the proportions collectors prize, with a silvered guilloché dial and blued hands.\n\nFreshly serviced in-house with two-year warranty; a graceful piece on any wrist.	{"caliber": "JLC 846/1", "bracelet": "Black alligator strap", "movement": "Manual winding", "dialColor": "Silvered guilloché", "functions": "Hours, minutes", "caseDiameter": "38 × 23mm", "caseMaterial": "Stainless steel", "powerReserve": "40 hours", "waterResistance": "30m"}	1
vc-01	vacheron-constantin-overseas-4500v	vacheron-constantin	Overseas Self-Winding	4500V/110A-B128	\N	24500	2021	Sport	Stainless steel	Unworn	Men	t	f	t	87	2025-10-05 00:00:00	The Overseas blue dial is the thinking collector's luxury sports watch — Geneva-seal finishing, Maltese-cross bezel, and three quick-release strap options.\n\n2021 example with bracelet, rubber and leather straps, all included.	{"caliber": "VC 5100", "bracelet": "Steel bracelet + 2 straps", "dialColor": "Blue lacquer", "functions": "Hours, minutes, seconds, date", "caseDiameter": "41mm", "caseMaterial": "Stainless steel", "powerReserve": "60 hours", "waterResistance": "150m"}	1
vc-02	vacheron-constantin-patrimony-85180	vacheron-constantin	Patrimony Self-Winding	85180/000R-9248	\N	25900	2020	Dress	Rose gold	Unworn	Men	t	f	f	71	2025-04-14 00:00:00	The Patrimony's convex dial and slender rose-gold case distil Genevan classicism into its purest modern form — a perpetual reference among dress watches.\n\nComplete 2020 set; unworn since a full manufacture service.	{"caliber": "VC 2450 Q6", "bracelet": "Brown alligator strap", "dialColor": "Silvered opaline", "functions": "Hours, minutes, seconds, date", "caseDiameter": "40mm", "caseMaterial": "18k rose gold", "powerReserve": "40 hours", "waterResistance": "30m"}	1
vc-03	vacheron-constantin-fiftysix-4600e	vacheron-constantin	Fiftysix Self-Winding	4600E/000A-B487	\N	13500	2022	Dress	Stainless steel	Unworn	Men	t	f	f	69	2025-07-26 00:00:00	The Fiftysix channels a 1956 Vacheron reference — box crystal, sector dial, Arabic-and-baton alternation — into the maison's most accessible line.\n\nSepia-toned dial, 2022, near new.	{"caliber": "VC 1326", "bracelet": "Brown calf strap", "dialColor": "Sepia brown sector", "functions": "Hours, minutes, seconds, date", "caseDiameter": "40mm", "caseMaterial": "Stainless steel", "powerReserve": "48 hours", "waterResistance": "30m"}	1
vc-04	vacheron-constantin-historiques-222	vacheron-constantin	Historiques 222	4200H/222J-B935	\N	78500	2024	Sport	Yellow gold	Unworn	Men	t	t	f	86	2025-11-08 00:00:00	Vacheron's faithful revival of its 1977 integrated-bracelet 222 — the maison's answer to the Genta era, in solid yellow gold with the tonneau-link bracelet.\n\nUnworn 2024 example; a modern classic already trading above retail.	{"caliber": "VC 2455/2", "bracelet": "Integrated gold bracelet", "dialColor": "Champagne gold", "functions": "Hours, minutes, date", "caseDiameter": "37mm", "caseMaterial": "18k yellow gold", "powerReserve": "40 hours", "waterResistance": "50m"}	1
gs-01	grand-seiko-snowflake-sbga211	grand-seiko	Heritage "Snowflake"	SBGA211	\N	5600	2022	Dress	Titanium	Unworn	Men	t	f	t	84	2025-08-11 00:00:00	The watch that made the world take Grand Seiko seriously — a white dial textured like wind-blown snow over the Spring Drive's perfectly smooth glide seconds.\n\nHigh-intensity titanium, 2022, complete set.	{"caliber": "Grand Seiko 9R65 Spring Drive", "bracelet": "Titanium bracelet", "dialColor": "Snow white", "functions": "Hours, minutes, seconds, date, power reserve", "caseDiameter": "41mm", "caseMaterial": "High-intensity titanium", "powerReserve": "72 hours", "waterResistance": "100m"}	1
gs-02	grand-seiko-sbgh269-japanese-maple	grand-seiko	Heritage Hi-Beat "Autumn"	SBGH269	\N	6900	2019	Dress	Stainless steel	Unworn	Men	t	f	f	62	2025-05-22 00:00:00	A limited Hi-Beat with a dial the colour of turning maple leaves — Grand Seiko's texture work at its most poetic.\n\n2019 limited edition, full set, superb condition.	{"caliber": "Grand Seiko 9S85 Hi-Beat", "bracelet": "Steel bracelet", "dialColor": "Crimson maple", "functions": "Hours, minutes, seconds, date", "caseDiameter": "39.5mm", "caseMaterial": "Stainless steel", "powerReserve": "55 hours", "waterResistance": "100m"}	1
gs-03	grand-seiko-sbgm221-gmt	grand-seiko	Elegance GMT	SBGM221	\N	4650	2021	GMT	Stainless steel	Unworn	Men	t	f	f	57	2025-03-03 00:00:00	A 39.5mm ivory-dial GMT with a box sapphire crystal and the most elegant blue GMT hand in the business — vintage proportions, modern movement.\n\nOn brown crocodile, 2021, excellent.	{"caliber": "Grand Seiko 9S66", "bracelet": "Brown crocodile strap", "dialColor": "Ivory", "functions": "Hours, minutes, seconds, date, GMT", "caseDiameter": "39.5mm", "caseMaterial": "Stainless steel", "powerReserve": "72 hours", "waterResistance": "30m"}	1
gs-04	grand-seiko-sbga415-taisetsu	grand-seiko	Heritage "Taisetsu" Seasons	SBGA415	\N	6150	2023	Dress	Stainless steel	Unworn	Men	t	t	f	66	2025-10-21 00:00:00	The Taisetsu — "deep snow" — dial renders a winter forest in layered greys, paired with Spring Drive's signature sweep.\n\nUnworn 2023 boutique edition with complete set.	{"caliber": "Grand Seiko 9R65 Spring Drive", "bracelet": "Steel bracelet", "dialColor": "Silver-grey textured", "functions": "Hours, minutes, seconds, date, power reserve", "caseDiameter": "40mm", "caseMaterial": "Stainless steel", "powerReserve": "72 hours", "waterResistance": "100m"}	1
rlx-01	rolex-submariner-date-126610ln	rolex	Submariner Date	126610LN	\N	14250	2023	Dive	Oystersteel	Unworn	Men	t	f	t	98	2025-10-02 00:00:00	The reference against which every dive watch is measured. This 2023 Submariner Date pairs a 41mm Oystersteel case with the calibre 3235, offering a 70-hour reserve and the superlative chronometer certification.\n\nPresented in unworn condition with full box and papers, the watch retains its factory bracelet sizing and protective bezel film.	{"caliber": "Rolex 3235", "bracelet": "Oyster bracelet, Oystersteel", "dialColor": "Black", "functions": "Hours, minutes, seconds, date", "caseDiameter": "41mm", "caseMaterial": "Oystersteel", "waterResistance": "300m"}	0
\.


--
-- Data for Name: WishlistItem; Type: TABLE DATA; Schema: public; Owner: aurelian
--

COPY public."WishlistItem" ("userId", "watchId", "createdAt") FROM stdin;
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: aurelian
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
d59706b9-12a8-4db1-9e5f-ec94a6aad145	9176c9cff0ef69c8ca8de6555295f8db66086fea5570c388edf52149bca4ffbb	2026-09-27 09:26:32.620275+00	0_init		\N	2026-09-27 09:26:32.620275+00	0
\.


--
-- Name: AuthToken AuthToken_pkey; Type: CONSTRAINT; Schema: public; Owner: aurelian
--

ALTER TABLE ONLY public."AuthToken"
    ADD CONSTRAINT "AuthToken_pkey" PRIMARY KEY (id);


--
-- Name: CartItem CartItem_pkey; Type: CONSTRAINT; Schema: public; Owner: aurelian
--

ALTER TABLE ONLY public."CartItem"
    ADD CONSTRAINT "CartItem_pkey" PRIMARY KEY ("userId", "watchId");


--
-- Name: ContactMessage ContactMessage_pkey; Type: CONSTRAINT; Schema: public; Owner: aurelian
--

ALTER TABLE ONLY public."ContactMessage"
    ADD CONSTRAINT "ContactMessage_pkey" PRIMARY KEY (id);


--
-- Name: NewsletterSubscriber NewsletterSubscriber_pkey; Type: CONSTRAINT; Schema: public; Owner: aurelian
--

ALTER TABLE ONLY public."NewsletterSubscriber"
    ADD CONSTRAINT "NewsletterSubscriber_pkey" PRIMARY KEY (id);


--
-- Name: OrderItem OrderItem_pkey; Type: CONSTRAINT; Schema: public; Owner: aurelian
--

ALTER TABLE ONLY public."OrderItem"
    ADD CONSTRAINT "OrderItem_pkey" PRIMARY KEY (id);


--
-- Name: Order Order_pkey; Type: CONSTRAINT; Schema: public; Owner: aurelian
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_pkey" PRIMARY KEY (id);


--
-- Name: Session Session_pkey; Type: CONSTRAINT; Schema: public; Owner: aurelian
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: aurelian
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: Watch Watch_pkey; Type: CONSTRAINT; Schema: public; Owner: aurelian
--

ALTER TABLE ONLY public."Watch"
    ADD CONSTRAINT "Watch_pkey" PRIMARY KEY (id);


--
-- Name: WishlistItem WishlistItem_pkey; Type: CONSTRAINT; Schema: public; Owner: aurelian
--

ALTER TABLE ONLY public."WishlistItem"
    ADD CONSTRAINT "WishlistItem_pkey" PRIMARY KEY ("userId", "watchId");


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: aurelian
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: AuthToken_tokenHash_key; Type: INDEX; Schema: public; Owner: aurelian
--

CREATE UNIQUE INDEX "AuthToken_tokenHash_key" ON public."AuthToken" USING btree ("tokenHash");


--
-- Name: NewsletterSubscriber_email_key; Type: INDEX; Schema: public; Owner: aurelian
--

CREATE UNIQUE INDEX "NewsletterSubscriber_email_key" ON public."NewsletterSubscriber" USING btree (email);


--
-- Name: Order_number_key; Type: INDEX; Schema: public; Owner: aurelian
--

CREATE UNIQUE INDEX "Order_number_key" ON public."Order" USING btree (number);


--
-- Name: Session_token_key; Type: INDEX; Schema: public; Owner: aurelian
--

CREATE UNIQUE INDEX "Session_token_key" ON public."Session" USING btree (token);


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: aurelian
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: Watch_slug_key; Type: INDEX; Schema: public; Owner: aurelian
--

CREATE UNIQUE INDEX "Watch_slug_key" ON public."Watch" USING btree (slug);


--
-- Name: AuthToken AuthToken_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aurelian
--

ALTER TABLE ONLY public."AuthToken"
    ADD CONSTRAINT "AuthToken_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: CartItem CartItem_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aurelian
--

ALTER TABLE ONLY public."CartItem"
    ADD CONSTRAINT "CartItem_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: CartItem CartItem_watchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aurelian
--

ALTER TABLE ONLY public."CartItem"
    ADD CONSTRAINT "CartItem_watchId_fkey" FOREIGN KEY ("watchId") REFERENCES public."Watch"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: OrderItem OrderItem_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aurelian
--

ALTER TABLE ONLY public."OrderItem"
    ADD CONSTRAINT "OrderItem_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public."Order"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: OrderItem OrderItem_watchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aurelian
--

ALTER TABLE ONLY public."OrderItem"
    ADD CONSTRAINT "OrderItem_watchId_fkey" FOREIGN KEY ("watchId") REFERENCES public."Watch"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Order Order_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aurelian
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Session Session_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aurelian
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: WishlistItem WishlistItem_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aurelian
--

ALTER TABLE ONLY public."WishlistItem"
    ADD CONSTRAINT "WishlistItem_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: WishlistItem WishlistItem_watchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aurelian
--

ALTER TABLE ONLY public."WishlistItem"
    ADD CONSTRAINT "WishlistItem_watchId_fkey" FOREIGN KEY ("watchId") REFERENCES public."Watch"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict UEAQAj1EyLFyHpvnTrByxUOsoLsEMdWQglUHjYhWDFgzFDXebAJLzky93gLOqG3

